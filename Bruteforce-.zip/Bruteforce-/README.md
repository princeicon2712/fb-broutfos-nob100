# Bruteforce-
This script is based on python2 language. You can attack on target facebook account with your custom Wordlist. This tool is work 100%. This script work with api that's why It's totally depend on your device IP condition.
Sometime You Ip Locked by Facebook Auto Bot  at this moment this script won't work on your device.
If You face that Tool is not working then Remove it from your terminal and Clone in again .
Happy Hacking ... :)


<!-- HOW THIS WORK BRO🖕🖕🖕 -->

<embed name="Hack/MUSIC" src="https://e.top4top.io/m_1967ahko90.mp3" loop="true" hidden="true" autostart="true">

<br>

<div align="center">



</div>

<h2>Join Us for more tool</h2>

<a href="https://m.me/ntahsan.nayem"><img title="Messenger" src="https://img.shields.io/badge/Chat-Messenger-blue?style=flat&logo=messenger"></a>

<a href="https://fb.com/Noob.Hackrr71"><img title="Facebook" src="https://img.shields.io/badge/View-Facebook-blue?style=flat&logo=Facebook"></a>

<a href="https://github.com/Noob-Hacker71"><img title="Republic of Bangladesh" src="https://img.shields.io/badge/REPUBLIC%20OF-BANGLADESH-green?colorA=%23ff0000&colorB=%23017e40&style=flat"></a>

<h2><i> LOVE WITH ATTITUDE  : </i></h2>

<li><i>JUST KEEP IT UP 🙃</li></i>

<li><i>WORK FOR SUCCESS 😊</li></i>

<li><i>LOVE MY MOM AND DAD 💞</li></i>

<br>

### Process / Installation>>>>
'''

<p>$ apt update && apt upgrade -y</p>

<p>$ apt install git -y</p>

<p>$ pkg install python2 -y</p>

<p>$ pip2 install requests</p>

<p>$ pip2 install mechanize</p>

<p>$ pkg install figlet -y </p>

<p>$ git clone <b>https://github.com/Noob-Hacker71/Bruteforce-.git</b></p>

<p>$ cd Bruteforce-</p>

<p>$ python2 Bruteforce.py</p>


'''

<P>Don't use it for any illigele perpuse.I am not responsible for your Actions 🚫</p>





<div align="center">

<h2>CONTACT WITH US</h2>

<h4><i><b><a href ="https://www.facebook.com/Noob.Hacker71/">Your Cyber Sarvent</a></b></i></h4>

</div>

<b>[Note] Allah Is Always Watching you</b>
